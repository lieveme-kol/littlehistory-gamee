extends Node2D

const LH_HERO = preload("res://scripts/lh_hero.gd")
const LH_ITEM = preload("res://scripts/lh_item.gd")
const LH_GIZMO = preload("res://scripts/lh_gizmo.gd")
const BOY_TEX = preload("res://assets/generated/male_hero.png")
const GIRL_TEX = preload("res://assets/generated/female_hero.png")
const HOME_BG = preload("res://assets/generated/cozy_home.png")
const FOREST_BG = preload("res://assets/generated/fairy_forest.png")
const STAR_BG = preload("res://assets/generated/starry_place.png")
const CYRILLIC_FONT = preload("res://assets/fonts/cyrillic_regular.tres")

const VIEW_SIZE := Vector2(1280, 720)
var levels: Array[Dictionary] = []
var current: Dictionary = {}
var level_index := 0
var world_width := 2400.0
var playing := true
var paused_local := false
var active_id := 0
var boy: LHHero
var girl: LHHero
var camera: Camera2D
var platform_data: Array = []
var item_nodes: Array = []
var gizmo_nodes: Array = []
var switch_states: Array[bool] = []
var checkpoint := Vector2.ZERO
var hearts := 0
var memories := 0
var unlocked_level := 0
var touch_left := false
var touch_right := false
var touch_jump := false
var touch_crouch := false
var jump_request := false
var interaction_request := false
var pair_timer := 0.0
var pair_interaction_index := 0
var hint_timer := 0.0
var message_timer := 0.0
var toast_text := ""
var hud_layer: CanvasLayer
var hud: Control
var level_label: Label
var hearts_label: Label
var memory_label: Label
var hint_label: Label
var active_label: Label
var toast_label: Label
var pause_panel: PanelContainer
var finish_panel: PanelContainer
var finish_title: Label
var finish_body: Label
var bg_texture: Texture2D
var theme_color := Color("#e6b7aa")

func _ready() -> void:
	_build_level_catalog()
	_load_save()
	var requested := int(get_tree().get_meta("littlehistory_start_level", unlocked_level))
	get_tree().set_meta("littlehistory_start_level", -1)
	level_index = clampi(requested, 0, levels.size() - 1)
	_build_level(level_index)
	_build_heroes()
	_build_hud()
	_show_toast("Соберите сердечки и найдите путь к воротам ♥", 4.0)
	queue_redraw()

func _build_level_catalog() -> void:
	levels = [
		{"title":"Уютный дом", "subtitle":"Дом, где начинается маленькая история", "bg":HOME_BG, "theme":Color("#d9b39d"), "width":2400.0, "spawn":Vector2(150, 585), "goal":2220.0, "required":1, "switches":[Vector2(790, 585)], "platforms":[[0,650,2400,100],[300,560,250,24],[690,500,230,24],[1050,585,260,24],[1420,505,240,24],[1760,570,270,24]], "hearts":[Vector2(420,515),Vector2(805,455),Vector2(1160,540),Vector2(1515,460),Vector2(1860,525)], "memories":[Vector2(1230,445)]},
		{"title":"Зелёный дворик", "subtitle":"Когда рядом — даже забор становится приключением", "bg":null, "theme":Color("#91b889"), "width":2700.0, "spawn":Vector2(130, 585), "goal":2500.0, "required":2, "switches":[Vector2(830,585),Vector2(1510,585)], "platforms":[[0,650,2700,100],[360,560,220,24],[700,490,190,24],[1080,570,230,24],[1390,475,240,24],[1740,560,260,24],[2110,470,220,24]], "hearts":[Vector2(440,515),Vector2(760,445),Vector2(1160,525),Vector2(1470,430),Vector2(1840,515),Vector2(2200,425)], "memories":[Vector2(1940,505)]},
		{"title":"Сказочный лес", "subtitle":"Секреты светятся только тем, кто ищет вместе", "bg":FOREST_BG, "theme":Color("#9b79a8"), "width":3000.0, "spawn":Vector2(130, 585), "goal":2800.0, "required":2, "switches":[Vector2(950,585),Vector2(2050,585)], "platforms":[[0,650,3000,100],[300,525,230,24],[640,420,190,24],[970,535,240,24],[1320,440,220,24],[1680,540,230,24],[2040,450,230,24],[2380,535,220,24]], "hearts":[Vector2(420,480),Vector2(710,370),Vector2(1080,490),Vector2(1410,390),Vector2(1770,495),Vector2(2130,400),Vector2(2470,490)], "memories":[Vector2(1500,380),Vector2(2580,470)]},
		{"title":"Особенное место", "subtitle":"Финал, который хочется запомнить", "bg":STAR_BG, "theme":Color("#7c769e"), "width":2800.0, "spawn":Vector2(130, 585), "goal":2570.0, "required":2, "switches":[Vector2(820,585),Vector2(1700,585)], "platforms":[[0,650,2800,100],[330,540,220,24],[670,455,220,24],[1020,545,230,24],[1370,460,220,24],[1680,550,240,24],[2050,465,250,24],[2350,545,220,24]], "hearts":[Vector2(430,495),Vector2(760,410),Vector2(1110,500),Vector2(1460,415),Vector2(1770,505),Vector2(2140,420),Vector2(2430,500)], "memories":[Vector2(1200,495),Vector2(2290,415)]}
	]

func _load_save() -> void:
	var cfg := ConfigFile.new()
	if cfg.load("user://littlehistory.cfg") == OK:
		unlocked_level = clampi(int(cfg.get_value("progress", "unlocked_level", 0)), 0, 3)
		hearts = int(cfg.get_value("progress", "hearts", 0))
		memories = int(cfg.get_value("progress", "memories", 0))

func _save_progress() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "unlocked_level", unlocked_level)
	cfg.set_value("progress", "hearts", hearts)
	cfg.set_value("progress", "memories", memories)
	cfg.save("user://littlehistory.cfg")

func _build_level(index: int) -> void:
	current = levels[index]
	world_width = float(current.width)
	bg_texture = current.bg
	theme_color = current.theme
	platform_data.clear()
	item_nodes.clear()
	gizmo_nodes.clear()
	for child in get_children():
		if child.is_in_group("lh_stage"):
			child.queue_free()
	switch_states.clear()
	for _i in current.switches.size():
		switch_states.append(false)
	checkpoint = current.spawn
	for p in current.platforms:
		_add_platform(Vector2(p[0], p[1]), Vector2(p[2], p[3]))
	for i in current.hearts:
		_add_item(Vector2(i[0], i[1]), "heart", "Сердечко")
	for m in current.memories:
		_add_item(Vector2(m[0], m[1]), "memory", "Памятный предмет")
	for idx in current.switches.size():
		_add_gizmo(current.switches[idx], "switch", "Механизм %d" % (idx + 1))
	_add_gizmo(Vector2(float(current.goal), 650), "door", "Финиш")
	_add_gizmo(Vector2(float(current.spawn.x) + 70.0, 650), "checkpoint", "Старт")
	queue_redraw()

func _add_platform(pos: Vector2, size: Vector2) -> void:
	platform_data.append({"pos":pos, "size":size})
	var body := StaticBody2D.new()
	body.position = pos + size * 0.5
	body.collision_layer = 1
	body.add_to_group("lh_stage")
	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = size
	shape.shape = rect
	body.add_child(shape)
	add_child(body)

func _add_item(pos: Vector2, kind: String, title: String) -> void:
	var item := LH_ITEM.new()
	item.position = pos
	item.setup(kind, title)
	item.collected.connect(_on_item_collected)
	item.add_to_group("lh_stage")
	add_child(item)
	item_nodes.append(item)

func _add_gizmo(pos: Vector2, kind: String, title: String) -> void:
	var gizmo := LH_GIZMO.new()
	gizmo.position = pos
	gizmo.setup(kind, title)
	gizmo.add_to_group("lh_stage")
	add_child(gizmo)
	gizmo_nodes.append(gizmo)

func _build_heroes() -> void:
	boy = LH_HERO.new()
	boy.name = "Парень"
	boy.setup(self, 0, BOY_TEX)
	add_child(boy)
	girl = LH_HERO.new()
	girl.name = "Девушка"
	girl.setup(self, 1, GIRL_TEX)
	add_child(girl)
	_reset_heroes()
	camera = Camera2D.new()
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 6.0
	camera.limit_left = 0
	camera.limit_right = int(world_width)
	camera.limit_top = 0
	camera.limit_bottom = 720
	add_child(camera)
	camera.position = boy.position + Vector2(0, -115)

func _reset_heroes() -> void:
	boy.set_spawn(current.spawn)
	girl.set_spawn(current.spawn + Vector2(78, 0))
	boy.set_active(active_id == 0)
	girl.set_active(active_id == 1)
	boy.set_emotion("", 0.0)
	girl.set_emotion("", 0.0)

func _build_hud() -> void:
	var mobile := _is_mobile_layout()
	var viewport := get_viewport_rect().size
	hud_layer = CanvasLayer.new()
	hud_layer.layer = 20
	add_child(hud_layer)
	hud = Control.new()
	hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_layer.add_child(hud)
	var top := PanelContainer.new()
	top.position = Vector2(12 if mobile else 20, 12 if mobile else 18)
	# Reserve a dedicated lane for the pause button on narrow screens.
	top.size = Vector2(maxf(220.0, viewport.x - (92.0 if mobile else 24.0)) if mobile else 600.0, 84 if mobile else 86)
	top.add_theme_stylebox_override("panel", _panel_style(Color(0.12, 0.10, 0.18, 0.78), Color("#f5d9b8"), 2, 18))
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud.add_child(top)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 6 if mobile else 16)
	top.add_child(row)
	level_label = _hud_label("УРОВЕНЬ 1\nУютный дом", 16 if mobile else 21)
	hearts_label = _hud_label("♥ 0", 17 if mobile else 22)
	memory_label = _hud_label("✦ 0", 17 if mobile else 22)
	active_label = _hud_label("Сейчас: парень", 12 if mobile else 16)
	row.add_child(level_label)
	row.add_child(hearts_label)
	row.add_child(memory_label)
	row.add_child(active_label)
	var pause := _button("Ⅱ", Vector2(54, 54))
	pause.position = Vector2(viewport.x - 66.0, 12 if mobile else 18)
	pause.mouse_filter = Control.MOUSE_FILTER_STOP
	pause.pressed.connect(toggle_pause)
	hud.add_child(pause)
	var hint_panel := PanelContainer.new()
	# Keep tutorial text above the touch-control area instead of underneath it.
	hint_panel.position = Vector2(12, viewport.y - 248.0) if mobile else Vector2(300, 548)
	hint_panel.size = Vector2(viewport.x - 24.0, 58) if mobile else Vector2(680, 58)
	hint_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.12,0.09,0.16,0.78), Color("#f4c7a3"), 2, 18))
	hud.add_child(hint_panel)
	hint_label = _hud_label("", 17)
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	hint_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint_panel.add_child(hint_label)
	toast_label = _hud_label("", 20)
	toast_label.position = Vector2(10, 106) if mobile else Vector2(350, 125)
	toast_label.size = Vector2(viewport.x - 20.0, 48) if mobile else Vector2(580, 48)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.add_theme_color_override("font_color", Color("#ffecc9"))
	toast_label.add_theme_color_override("font_outline_color", Color("#39283f"))
	toast_label.add_theme_constant_override("outline_size", 6)
	hud.add_child(toast_label)
	_build_touch_controls()
	_build_pause_panel()
	_build_finish_panel()
	_update_hud()

func _hud_label(text: String, size: int) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_override("font", CYRILLIC_FONT)
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", Color("#fff0d0"))
	label.add_theme_color_override("font_outline_color", Color(0.16, 0.10, 0.18, 0.8))
	label.add_theme_constant_override("outline_size", 4)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label

func _panel_style(fill: Color, border: Color, width: int, radius: int) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = fill
	style.border_color = border
	style.set_border_width_all(width)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style

func _button(text: String, button_size: Vector2) -> Button:
	var b := Button.new()
	b.text = text
	b.add_theme_font_override("font", CYRILLIC_FONT)
	b.custom_minimum_size = button_size
	b.add_theme_font_size_override("font_size", 22)
	b.add_theme_color_override("font_color", Color("#fff0d0"))
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_stylebox_override("normal", _panel_style(Color(0.18,0.13,0.22,0.9), Color("#e9b7a0"), 2, 16))
	b.add_theme_stylebox_override("hover", _panel_style(Color("#8f536e"), Color("#ffe0bf"), 3, 16))
	b.add_theme_stylebox_override("pressed", _panel_style(Color("#543d63"), Color("#f5bf9e"), 3, 16))
	return b

func _is_mobile_layout() -> bool:
	return get_viewport_rect().size.x < 900.0

func _build_touch_controls() -> void:
	var mobile := _is_mobile_layout()
	var viewport := get_viewport_rect().size
	if mobile:
		# Separate movement, action and utility zones. Touch targets are larger,
		# with a clear gap between every control to prevent accidental taps.
		var bottom_y := viewport.y - 78.0
		var utility_y := viewport.y - 158.0
		var left_size := Vector2(76, 66)
		var action_size := Vector2(94, 66)
		var utility_size := Vector2(76, 62)

		var left := _button("◀", left_size)
		left.position = Vector2(12, bottom_y)
		left.button_down.connect(func(): touch_left = true)
		left.button_up.connect(func(): touch_left = false)
		hud.add_child(left)

		var right := _button("▶", left_size)
		right.position = Vector2(98, bottom_y)
		right.button_down.connect(func(): touch_right = true)
		right.button_up.connect(func(): touch_right = false)
		hud.add_child(right)

		var jump := _button("ПРЫЖОК", action_size)
		jump.position = Vector2(viewport.x - action_size.x - 12.0, bottom_y)
		jump.add_theme_font_size_override("font_size", 18)
		jump.button_down.connect(func(): touch_jump = true; jump_request = true)
		jump.button_up.connect(func(): touch_jump = false)
		hud.add_child(jump)

		var crouch := _button("ПРИСЕСТЬ", action_size)
		crouch.add_theme_font_size_override("font_size", 14)
		crouch.position = Vector2(viewport.x - action_size.x - 12.0, utility_y)
		crouch.add_theme_font_size_override("font_size", 30)
		crouch.tooltip_text = "Удерживайте, чтобы присесть"
		crouch.button_down.connect(func(): touch_crouch = true)
		crouch.button_up.connect(func(): touch_crouch = false)
		hud.add_child(crouch)

		var switch_button := _button("⇄", utility_size)
		switch_button.position = Vector2(12, utility_y)
		switch_button.add_theme_font_size_override("font_size", 26)
		switch_button.tooltip_text = "Сменить персонажа"
		switch_button.pressed.connect(switch_hero)
		hud.add_child(switch_button)

		var interact := _button("✦", utility_size)
		interact.position = Vector2(98, utility_y)
		interact.add_theme_font_size_override("font_size", 26)
		interact.tooltip_text = "Взаимодействовать"
		interact.pressed.connect(func(): interaction_request = true)
		hud.add_child(interact)
	else:
		var bottom_y := viewport.y - 86.0
		var left := _button("◀", Vector2(82, 70))
		left.position = Vector2(26, bottom_y)
		left.button_down.connect(func(): touch_left = true)
		left.button_up.connect(func(): touch_left = false)
		hud.add_child(left)

		var right := _button("▶", Vector2(82, 70))
		right.position = Vector2(116, bottom_y)
		right.button_down.connect(func(): touch_right = true)
		right.button_up.connect(func(): touch_right = false)
		hud.add_child(right)

		var switch_button := _button("⇄", Vector2(82, 70))
		switch_button.position = Vector2(918, bottom_y)
		switch_button.pressed.connect(switch_hero)
		hud.add_child(switch_button)

		var interact := _button("✦", Vector2(82, 70))
		interact.position = Vector2(1008, bottom_y)
		interact.pressed.connect(func(): interaction_request = true)
		hud.add_child(interact)

		var crouch := _button("ПРИСЕСТЬ", Vector2(100, 70))
		crouch.position = Vector2(808, bottom_y)
		crouch.button_down.connect(func(): touch_crouch = true)
		crouch.button_up.connect(func(): touch_crouch = false)
		hud.add_child(crouch)

		var jump := _button("ПРЫЖОК", Vector2(132, 70))
		jump.position = Vector2(viewport.x - 162.0, bottom_y)
		jump.button_down.connect(func(): touch_jump = true; jump_request = true)
		jump.button_up.connect(func(): touch_jump = false)
		hud.add_child(jump)

func _build_pause_panel() -> void:
	pause_panel = PanelContainer.new()
	pause_panel.position = Vector2(430, 150)
	pause_panel.size = Vector2(420, 380)
	pause_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.10,0.08,0.16,0.97), Color("#f0b5a8"), 3, 26))
	pause_panel.visible = false
	hud.add_child(pause_panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	pause_panel.add_child(box)
	var title := _hud_label("ПАУЗА", 30)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)
	var resume := _button("Продолжить", Vector2(0, 54))
	resume.pressed.connect(toggle_pause)
	box.add_child(resume)
	var restart := _button("Перезапустить уровень", Vector2(0, 54))
	restart.pressed.connect(restart_level)
	box.add_child(restart)
	var menu := _button("В главное меню", Vector2(0, 54))
	menu.pressed.connect(return_to_menu)
	box.add_child(menu)
	var controls := _hud_label("Используйте экранные кнопки, чтобы двигаться, прыгать, приседать\nи переключаться между героями.", 15)
	controls.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(controls)

func _build_finish_panel() -> void:
	finish_panel = PanelContainer.new()
	finish_panel.position = Vector2(330, 155)
	finish_panel.size = Vector2(620, 350)
	finish_panel.add_theme_stylebox_override("panel", _panel_style(Color(0.12,0.08,0.17,0.98), Color("#f4c18f"), 3, 28))
	finish_panel.visible = false
	hud.add_child(finish_panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	finish_panel.add_child(box)
	finish_title = _hud_label("", 32)
	finish_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(finish_title)
	finish_body = _hud_label("", 18)
	finish_body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	finish_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(finish_body)
	var next := _button("Дальше", Vector2(0, 56))
	next.name = "NextButton"
	next.pressed.connect(next_level)
	box.add_child(next)
	var menu := _button("В меню", Vector2(0, 48))
	menu.pressed.connect(return_to_menu)
	box.add_child(menu)

func _process(delta: float) -> void:
	if hint_timer > 0.0:
		hint_timer -= delta
	if pair_timer > 0.0:
		pair_timer -= delta
	if message_timer > 0.0:
		message_timer -= delta
		if message_timer <= 0.0:
			toast_label.text = ""
	if camera != null and playing:
		var target := boy.position if active_id == 0 else girl.position
		camera.position = target + Vector2(0, -115)
	if interaction_request:
		interaction_request = false
		_interact()
	_update_hud()

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			toggle_pause()
		elif event.keycode == KEY_TAB:
			switch_hero()
		elif event.keycode == KEY_E:
			interaction_request = true
		elif event.keycode == KEY_R and paused_local:
			restart_level()
		elif event.keycode == KEY_SPACE:
			jump_request = true
	if event is InputEventKey and not event.pressed and event.keycode == KEY_SPACE:
		touch_jump = false

func input_axis() -> float:
	var axis := Input.get_axis("move_left", "move_right")
	if touch_left: axis -= 1.0
	if touch_right: axis += 1.0
	return clampf(axis, -1.0, 1.0)

func is_run_pressed() -> bool:
	return Input.is_key_pressed(KEY_SHIFT)

func is_crouch_pressed() -> bool:
	return touch_crouch

func consume_jump_request() -> bool:
	if not jump_request:
		return false
	jump_request = false
	return true

func switch_hero() -> void:
	if not playing or paused_local:
		return
	active_id = 1 - active_id
	boy.set_active(active_id == 0)
	girl.set_active(active_id == 1)
	var current_hero := "парень" if active_id == 0 else "девушка"
	boy.set_emotion("удивление", 0.45)
	girl.set_emotion("удивление", 0.45)
	_show_toast("Теперь управляется %s" % current_hero, 1.5)

func hero_fell(hero: LHHero) -> void:
	if not playing:
		return
	hero.global_position = checkpoint
	hero.velocity = Vector2.ZERO
	hero.set_emotion("грусть", 1.0)
	_show_toast("Не страшно — возвращаемся к контрольной точке", 2.0)

func _interact() -> void:
	if not playing or paused_local:
		return
	var hero := boy if active_id == 0 else girl
	var partner := girl if active_id == 0 else boy
	if hero.global_position.distance_to(partner.global_position) < 125.0:
		var moments := ["Объятие", "Держатся за руки", "Танец на месте", "Сели рядом и улыбаются"]
		pair_timer = 2.2
		boy.set_emotion("радость", 2.2)
		girl.set_emotion("радость", 2.2)
		_show_toast("Совместный момент: %s ♥" % moments[pair_interaction_index], 1.8)
		pair_interaction_index = (pair_interaction_index + 1) % moments.size()
		return
	for i in current.switches.size():
		if hero.global_position.distance_to(current.switches[i]) < 105.0:
			switch_states[i] = not switch_states[i]
			if i < gizmo_nodes.size(): gizmo_nodes[i].set_active(switch_states[i])
			hero.set_emotion("радость", 0.8)
			_show_toast("Механизм %d %s" % [i + 1, "включён" if switch_states[i] else "выключен"], 1.5)
			if _all_switches_active():
				var door: LHGizmo = gizmo_nodes[current.switches.size()] as LHGizmo
				door.set_active(true)
				_show_toast("Путь открыт! Ищите ворота ♥", 2.2)
			return
	var goal_pos := Vector2(float(current.goal), 600)
	if hero.global_position.distance_to(goal_pos) < 135.0:
		if _all_switches_active():
			complete_level()
		else:
			_show_toast("Нужно активировать все механизмы", 2.0)

func _all_switches_active() -> bool:
	for state in switch_states:
		if not state: return false
	return true

func _on_item_collected(item: LHItem) -> void:
	if item.kind == "heart":
		hearts += 1
		_show_toast("Сердечко найдено! ♥", 1.25)
	else:
		memories += 1
		_show_toast("Памятный предмет сохранён в истории ✦", 1.8)
	_save_progress()
	_update_hud()

func complete_level() -> void:
	if not playing: return
	playing = false
	paused_local = false
	boy.set_emotion("радость", 6.0)
	girl.set_emotion("радость", 6.0)
	unlocked_level = max(unlocked_level, min(level_index + 1, 3))
	_save_progress()
	finish_panel.visible = true
	if level_index == levels.size() - 1:
		finish_title.text = "Ваша маленькая история завершена ♥"
		finish_body.text = "Вы собрали %d сердечек и %d памятных предметов.\nОни прошли весь путь вместе — и это главное." % [hearts, memories]
		finish_panel.get_node("VBoxContainer/NextButton").text = "Сыграть сначала"
	else:
		finish_title.text = "Уровень пройден!"
		finish_body.text = "%s\nСобрано сердечек: %d · памятных предметов: %d" % [current.title, hearts, memories]
		finish_panel.get_node("VBoxContainer/NextButton").text = "Следующий уровень"

func next_level() -> void:
	finish_panel.visible = false
	if level_index >= levels.size() - 1:
		level_index = 0
	else:
		level_index += 1
	playing = true
	active_id = 0
	_build_level(level_index)
	_reset_heroes()
	camera.limit_right = int(world_width)
	camera.position = boy.position + Vector2(0, -115)
	_show_toast("%s — %s" % [current.title, current.subtitle], 3.0)

func restart_level() -> void:
	paused_local = false
	pause_panel.visible = false
	playing = true
	_build_level(level_index)
	_reset_heroes()
	camera.limit_right = int(world_width)
	camera.position = boy.position + Vector2(0, -115)
	_show_toast("Уровень перезапущен", 1.4)

func toggle_pause() -> void:
	if not playing or finish_panel.visible: return
	paused_local = not paused_local
	pause_panel.visible = paused_local
	boy.set_physics_process(not paused_local)
	girl.set_physics_process(not paused_local)

func return_to_menu() -> void:
	_save_progress()
	get_tree().change_scene_to_file("res://scenes/title_screen.tscn")

func _show_toast(text: String, duration: float) -> void:
	toast_text = text
	message_timer = duration
	if toast_label != null:
		toast_label.text = toast_text

func _update_hud() -> void:
	if level_label == null: return
	level_label.text = "УРОВЕНЬ %d\n%s" % [level_index + 1, current.title]
	hearts_label.text = "♥ %d" % hearts
	memory_label.text = "✦ %d" % memories
	active_label.text = "Сейчас: %s" % ("парень" if active_id == 0 else "девушка")
	var hero := boy if active_id == 0 else girl
	var nearby_switch := false
	for s in current.switches:
		if hero.global_position.distance_to(s) < 125.0: nearby_switch = true
	if nearby_switch:
		hint_label.text = "Нажмите ✦, чтобы активировать механизм. Второй герой поможет открыть путь."
	elif not _all_switches_active():
		hint_label.text = "Ищите механизмы, собирайте ♥ и переключайтесь кнопкой ⇄."
	else:
		hint_label.text = "Все механизмы активны — доберитесь до светящихся ворот."

func _draw() -> void:
	var rect := Rect2(0, 0, world_width, VIEW_SIZE.y)
	if bg_texture != null:
		draw_texture_rect(bg_texture, rect, false)
	else:
		_draw_courtyard(rect)
	# Soft foreground veil creates contrast for the actors.
	draw_rect(Rect2(0, 565, world_width, 155), Color(0.12, 0.09, 0.16, 0.10))
	for p in platform_data:
		var r := Rect2(p.pos, p.size)
		draw_rect(r, Color("#56485f"), true)
		draw_rect(Rect2(r.position, Vector2(r.size.x, 9)), theme_color.lightened(0.22), true)
		draw_line(r.position + Vector2(6, 6), r.position + Vector2(r.size.x - 6, 6), Color(1, 0.9, 0.75, 0.42), 2.0)
		for x in range(int(r.position.x + 20), int(r.end.x - 10), 42):
			draw_line(Vector2(x, r.position.y + 14), Vector2(x + 15, r.end.y - 5), Color(0.08,0.06,0.11,0.18), 2.0)
	# A small level marker at the far edge makes the journey readable.
	draw_string(ThemeDB.fallback_font, Vector2(float(current.goal) - 85.0, 520), "ОСОБЕННЫЙ МОМЕНТ", HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#fff0c8"))

func _draw_courtyard(rect: Rect2) -> void:
	draw_rect(rect, Color("#bfe0c2"), true)
	draw_circle(Vector2(210, 140), 90, Color("#f7d28f"))
	for i in 8:
		var hill_x := float(i) * 380.0
		draw_colored_polygon(PackedVector2Array([Vector2(hill_x, 520),Vector2(hill_x+180,330),Vector2(hill_x+360,520)]), Color("#93ba94"))
	for x in range(120, int(world_width), 320):
		var trunk := Vector2(x, 535)
		draw_rect(Rect2(trunk.x - 13, trunk.y - 120, 26, 120), Color("#7b594e"), true)
		draw_circle(trunk + Vector2(-35,-130), 52, Color("#6f9b77"))
		draw_circle(trunk + Vector2(30,-145), 58, Color("#80ab78"))
		draw_circle(trunk + Vector2(4,-180), 45, Color("#a8c887"))
	for x in range(90, int(world_width), 90):
		draw_circle(Vector2(x, 620 + sin(x) * 3), 5, Color("#f3a0ad"))
		draw_circle(Vector2(x + 8, 614 + sin(x) * 3), 5, Color("#f6d17f"))
