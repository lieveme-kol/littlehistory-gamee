extends Area2D
class_name LHItem

signal collected(item: LHItem)
var kind := "heart"
var title := ""
var anim_time := 0.0
var taken := false

func setup(item_kind: String, item_title: String = "") -> void:
	kind = item_kind
	title = item_title
	collision_layer = 0
	collision_mask = 2
	var shape := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = 32.0
	shape.shape = circle
	add_child(shape)
	body_entered.connect(_on_body_entered)
	queue_redraw()

func _process(delta: float) -> void:
	if taken:
		return
	anim_time += delta
	position.y += sin(anim_time * 2.4) * 0.12
	rotation = sin(anim_time * 1.7) * 0.04
	queue_redraw()

func _on_body_entered(body: Node) -> void:
	if taken or not body.is_in_group("lh_hero"):
		return
	taken = true
	collected.emit(self)
	queue_free()

func _draw() -> void:
	var pulse := 1.0 + sin(anim_time * 3.0) * 0.06
	if kind == "heart":
		var points := PackedVector2Array([Vector2(0, 20), Vector2(-23, -5), Vector2(-21, -17), Vector2(-12, -25), Vector2(0, -16), Vector2(12, -25), Vector2(21, -17), Vector2(23, -5)])
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(pulse, pulse))
		draw_colored_polygon(points, Color("#ef829c"))
		draw_polyline(PackedVector2Array([points[0], points[1], points[2], points[3], points[4], points[5], points[6], points[7], points[0]]), Color("#542f42"), 3.0, true)
		draw_circle(Vector2(-9, -12), 4.0, Color(1, 0.93, 0.95, 0.8))
	else:
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(pulse, pulse))
		draw_circle(Vector2.ZERO, 24.0, Color("#f5cf82"))
		draw_arc(Vector2.ZERO, 24.0, 0.0, TAU, 32, Color("#694c55"), 3.0, true)
		draw_circle(Vector2.ZERO, 13.0, Color("#fff3cc"))
		draw_string(ThemeDB.fallback_font, Vector2(-8, 7), "✦", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color("#d78771"))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
